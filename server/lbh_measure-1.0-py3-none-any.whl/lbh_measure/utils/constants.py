#  Add any constants/environment variables here

# Get the Model from mounted model share store
ML_MODEL_PATH = "/models/hardware/dev/v0/epoch=15-step=79.ckpt"
COSMOS_DATABASE_NAME = 'measure'
COSMOS_CONTAINER_NAME = 'audit'
BLOB_CONTAINER_NAME = 'tcprofilerimages'
